# MediLink Codebase, Workflow, and AI Audit

Audit date: 2026-08-24

## Scope and method

This is a static, repository-wide audit of the React/Vite frontend, Express API, Prisma/PostgreSQL schema, role and authorization model, operational workflows, AI agents, migration tooling, deployment files, and available validation commands. No application code was changed as part of the audit. The only repository edits are this requested document and its `.gitignore` entry.

Validation performed:

- Frontend production build: passes (`npm run build`), with a warning that the Billing chunk is over 500 kB.
- Backend JavaScript syntax checks: pass for all JavaScript files outside `node_modules`.
- Prisma schema validation: passes (`npx prisma validate`).
- Automated backend/frontend test suites: none are configured.
- Live end-to-end/database verification: not performed; it requires a running seeded PostgreSQL instance and test credentials.

The repository was already substantially dirty when the audit began. Existing changes were treated as user-owned.

## Executive assessment

MediLink is a broad, navigable hospital-management demo with working build plumbing, a normalized Prisma schema, role-specific dashboards, and a coherent set of AI UI surfaces. It is not production-ready for clinical or financial use. The largest risks are broken object-level authorization, non-atomic clinical/financial workflows, misleading AI and notification fallbacks, missing validation and auditability, and several frontend calls that have no matching API endpoint.

The most urgent issue is not feature completeness but confidentiality and integrity. Authentication and coarse role checks exist, yet many record-by-ID endpoints do not verify that a patient owns the record or that a clinician has a legitimate relationship with the patient. Any authenticated user who obtains an identifier can potentially retrieve sensitive records. Some clinical mutations also allow users with broad roles to affect unrelated patients or appointments.

## Architecture and current workflow map

### Runtime architecture

- Frontend: React 18, React Router, Axios, Vite, role-specific menus and dashboards.
- Backend: Express with JWT bearer authentication, route-level role checks, Helmet, CORS, and rate limiting.
- Persistence: Prisma 5 with PostgreSQL; legacy Mongo identifiers are retained for compatibility.
- Files: avatar uploads are stored on local disk and served directly from `/uploads`.
- AI: OpenRouter-compatible chat completions with JSON parsing and automatic deterministic fallbacks.
- Deployment: Dockerfiles and Compose manifests exist; production frontend defaults to a hard-coded Render backend if `VITE_BACKEND_URL` is absent.

### Primary workflows

| Workflow | Current path | Assessment |
|---|---|---|
| Registration/login | Public registration creates a Patient user, then attempts a Patient profile; JWT stored in browser local storage | Functional happy path, but profile creation is not atomic and token storage increases XSS impact |
| Password reset | Email lookup, token persistence, email delivery, token-based reset | Implemented, but leaks whether an email exists and lacks explicit input validation on reset endpoints |
| Patient administration | Reception/Admin creates patient/user; clinicians view and update records | Broadly implemented, but object-level authorization and transactional creation/deletion are inadequate |
| Doctor/staff administration | Admin/Reception creates doctors; Admin manages staff | Functional surfaces exist; role/sub-role semantics are inconsistent across layers |
| Appointment booking | Patient/Doctor/Reception/Admin books; availability check and conflict query; status update can create consultation bill | Core path exists; ownership checks, concurrency protection, state transitions, and notification truthfulness are weak |
| Prescribing/dispensing | Doctor creates prescription; pharmacist dispenses/refills and decrements inventory | Substantial implementation; concurrency, authorization scope, and atomicity need hardening |
| Ward/bed management | Authorized operational roles allocate/assign/release/discharge beds | Duplicate legacy/new flows exist; invariant protection and authorization are incomplete |
| Billing | Authorized staff creates bill; patient self-pays; staff records partial payments; insurance status updates | UI/API coverage is broad, but payment actions are ledger simulations and race/overpayment protections are insufficient |
| Reports | Admin-only operational reports | Implemented but partly disconnected: controller contains report functions that are not routed or exposed by the UI service |
| Notifications | Role-specific notification dropdown | Static demo data presented as live operational events |
| AI suite | Seven UI agents plus operational admin/pharmacy intelligence and chatbot booking | Useful demo integration, but access control, validation, safety, provenance, monitoring, and transactional boundaries are not production-grade |

## Critical findings (P0)

### P0-1: Broken object-level authorization exposes protected health and financial data

Evidence and impact:

- `GET /api/patients/:id`, `/medical-records`, `/appointments`, and `/stats` are authenticated but not role- or ownership-scoped at the route level; their controllers fetch the requested patient without enforcing patient ownership or care-team assignment.
- `GET /api/billing/:id` checks pharmacist bill type but does not verify that a Patient owns the requested bill.
- `GET /api/appointments/:id` fetches a record without verifying that the requester is its patient or doctor.
- `GET /api/prescriptions/:id` needs equivalent ownership/care-team enforcement.
- `GET /api/ai/patient-summary/:patientId` explicitly permits Patient and Receptionist roles but does not enforce “patient can access own only”; it sends aggregated medical, prescription, appointment, and billing context to the LLM provider.

Required outcome: centralize record-level policies and apply them to every list, detail, mutation, export, and AI endpoint. Default to deny. A patient may access only their own records; clinicians need a defined relationship or privileged emergency-access flow; operational roles receive minimum necessary fields.

### P0-2: AI endpoints expose high-risk clinical tools to every authenticated role

All AI routes pass through authentication, but symptom analysis, report analysis, health risk, bed allocation, appointment optimization, and chatbot endpoints have no role restrictions. The `/ai-agents` frontend route is also available to every logged-in user. A patient can invoke operational bed allocation; nonclinical staff can invoke report analysis; the AI summary issue above is more severe because it retrieves stored EHR data.

Required outcome: define an explicit role/feature matrix, enforce it in the backend, restrict the UI for usability only, and test denial paths. AI authorization must never rely on hidden navigation.

### P0-3: Default JWT secret permits token forgery when configuration is missing

Authentication verifies tokens with `process.env.JWT_SECRET || 'fallback_secret'`. A missing production secret silently activates a known credential and makes account impersonation possible.

Required outcome: fail startup outside a tightly marked test environment when JWT secret, database URL, or other mandatory secrets are absent. Add secret length/entropy checks and key rotation/version strategy.

### P0-4: Multi-record clinical and financial changes are not consistently transactional

Examples include registration followed by patient-profile creation, patient/doctor/staff user-plus-profile creation, appointment completion followed by bill creation, prescription dispense followed by stock changes, ward assignment/discharge plus counters/history, and deletion of a profile followed by deletion of its user. Partial failure can leave orphan users, missing profiles, inconsistent bed counts, stock/billing divergence, or completed care without the expected bill.

Required outcome: wrap each business operation in a Prisma transaction, establish idempotency keys for retryable actions, and enforce database constraints for invariants.

## High-priority findings (P1)

### Authorization and privacy

- List endpoints often permit broad clinical/operational access to the full patient directory. Field-level minimization is absent; contact and clinical data are returned together.
- Doctors can update patient metadata without a demonstrated patient relationship. Nurses can mutate medical history for any known patient.
- Doctor update endpoints allow any Doctor role to target another doctor's ID unless the controller explicitly blocks it; the same pattern should be audited for appointment status changes.
- Medical-history update/delete looks up the patient and history item independently, without verifying that `historyId` belongs to `patientId`. This is cross-record mutation risk.
- Static uploads are publicly served once the URL is known. There is no authorization gate, signed URL, malware scanning, retention policy, or remote object storage strategy.
- API logs include every URL; query strings can contain search terms or identifiers and should be redacted in healthcare contexts.
- OpenRouter requests may contain symptoms, report text, and full patient context. There is no consent record, data-processing configuration, de-identification, regional control, retention statement, or egress audit.

### Authentication and account lifecycle

- JWTs are stored in `localStorage`; any successful XSS can exfiltrate them. No refresh-token rotation, revocation list, logout endpoint, session inventory, or device/session controls exist.
- The frontend exports `logout()` calling `/api/auth/logout`, but no backend route exists. Current UI logout appears local-only.
- Forgot-password returns 404 for unknown accounts, enabling email enumeration.
- Reset-password and update-password routes lack route-level validators equivalent to registration; password complexity is minimal and inconsistent with the seeded `Password123!` convention.
- Registration creates the user first and merely logs patient-profile failure, then still returns success and a token. The `heal-orphans` endpoint confirms this known failure mode.
- Role and sub-role modeling is inconsistent: Prisma has primary roles plus `Staff` sub-roles, while application code also treats Nurse, Receptionist, and Pharmacist as primary roles. `Lab Technician` and `Ward Manager` exist only as sub-roles, while README lists additional roles not represented by the schema (Radiology Tech, Billing Staff).
- `getUserPermissions` dereferences permissions for unknown/Staff roles without a safe fallback, and its declared permission matrix does not consistently match actual route middleware.

### Appointment workflow

- Appointment route validation still uses `isMongoId()` for an optional patient identifier even though active IDs are UUIDs. Staff-created appointments supplying Prisma UUIDs can fail validation.
- Availability and booking use a query-then-create pattern without a database uniqueness constraint, lock, or serializable transaction. Concurrent requests can double-book a doctor/time slot.
- Time values are strings, with no schema-level guarantee that start precedes end, slots do not overlap, or time zones are handled consistently.
- Status updates are not implemented as an explicit state machine; invalid real-world transitions can occur (for example, Completed back to Scheduled or Cancelled after billing).
- Completing an appointment can create a bill, but the appointment-to-bill relation/idempotency guarantee is unclear. Retries or status toggles risk duplicate/missing billing.
- Patient cancellation authorization must enforce ownership; it is currently only role-gated.
- Rescheduling excludes Patient even though patient cancellation is allowed, and product intent is not documented.
- Email fallback may report a notification as “queued (mock)” even though there is no durable queue or eventual delivery mechanism.
- The chatbot returns hard-coded time slots when the availability request fails. That can lead users to select unavailable times and conceals an operational failure.
- The frontend service exports appointment deletion, but the backend has no `DELETE /appointments/:id` route.

### Patient and clinical-record workflow

- Frontend patient service exports `/patients/:id/history`, `/prescriptions`, and `/bills`, but these backend routes do not exist.
- The Test Reports UI and LabReport persistence are not a complete diagnostic workflow: there is no clear test order, specimen lifecycle, verification/sign-off, result amendment, clinician acknowledgement, or patient release policy.
- Clinical history and lab report payloads use free-form strings and lightly validated statuses; malformed dates/enums can reach Prisma and produce 500 errors rather than controlled 400 responses.
- There is no immutable clinical audit trail, version history, author identity on many clinical entries, or break-glass access logging.
- Patient deletion cascades clinical data and then deletes the user, which is unsuitable for regulated retention and can partially fail. A deactivate/archive workflow is needed.

### Prescription and pharmacy workflow

- Dispensing and stock decrement must be verified as one serializable transaction with conditional stock updates. Read-then-write logic can oversell under concurrency.
- Prescription status mutation and dispensing are split across overlapping endpoints, making invalid state combinations possible unless centralized in a state machine.
- Refill authorization is Pharmacist-only; clinical approval rules, refill limits, expiry, substitution, and controlled-drug handling are not modeled.
- Allergy, duplicate-therapy, interaction, contraindication, renal/hepatic dosing, and prescriber-signature checks are absent.
- Inventory batches are represented on Medicine rather than as a dedicated batch ledger, which prevents reliable FEFO dispensing, multi-expiry stock, recalls, and stock reconciliation.
- Inventory adjustments lack a durable, actor-attributed stock movement ledger.

### Ward and admission workflow

- Both legacy allocate/release and newer assign/discharge endpoints remain active, increasing invariant drift and maintenance risk.
- Bed availability is stored redundantly (`availableBeds` plus individual bed occupancy) and needs transactional reconciliation/check constraints.
- Bed assignment is not clearly tied to a first-class active Admission/Episode. `AdmissionHistory` is free-form and separate from Bed assignment lifecycle.
- Doctor, Receptionist, Nurse, and Ward Manager privileges overlap without a documented approval/escalation policy.
- Discharge should coordinate clinical discharge, bed release, ward charges, final bill, medication reconciliation, and follow-up; currently these are separate workflows.

### Billing and insurance workflow

- Patient “payment” immediately marks the full balance paid without integrating or verifying a payment gateway. It should be labeled demo/simulated or implemented through provider intents and signed webhooks.
- Payment recording uses read-modify-write without optimistic concurrency or a conditional update. Concurrent payment requests can overpay or lose updates.
- Insurance approval defaults to claimed amount and can make balance negative; it lacks caps against outstanding balance and duplicate-processing/idempotency protection.
- Financial data uses floating-point numbers. Currency should use integer minor units or an exact decimal type with explicit rounding rules.
- There are no refunds/voids/credit notes despite a Refunded status enum, no immutable double-entry/ledger model, and no reconciliation workflow.
- Bill deletion is allowed for unpaid bills; financial records generally need voiding with reason and audit history, not hard deletion.

## AI feature audit

### What is implemented

- Symptom checker: LLM or keyword fallback returns possible conditions, urgency, department, advice, and red flags.
- Report analyzer: LLM or deterministic templates produce patient-friendly findings.
- Health-risk calculator: LLM or point-based fallback produces a score and recommendations.
- Bed allocation: queries active wards/free beds, then recommends a ward type; it does not reserve a bed.
- Appointment optimizer: queries doctors and daily load, then recommends a department/doctor-related result; the prompt schema only guarantees department, urgency, rationale, and disclaimer.
- Patient summary: aggregates patient demographics/medical history, recent appointments, prescriptions, and billing metadata, then summarizes.
- Patient assistant: intent classification, text reply, navigation actions, plus a separate deterministic appointment-booking UI flow.
- Admin insights and pharmacy alerts: deterministic analytics; these are branded under AI but do not call an LLM.

### AI flaws and incomplete workflows

- Schema enforcement is best-effort JSON parsing only. There is no JSON Schema/Zod validation, type coercion, enum enforcement, range enforcement, or rejection of extra/unsafe fields.
- Prompt injection defenses are minimal. User report text/history is interpolated directly into prompts. The model can be induced to ignore output or safety instructions.
- Model output is not clinically validated before display. A disclaimer does not mitigate incorrect triage, hallucinated ranges, or unsafe advice.
- Emergency escalation is a keyword list in the floating chatbot. It is easy to miss paraphrases, multilingual input, negation, pediatric/obstetric emergencies, poisoning, self-harm, and other high-risk categories.
- Fallback output is presented as an AI result and automatic fallback can hide provider outages. Every response has `_source`, but the UI and audit trail do not consistently make provenance, model, fallback reason, or confidence obvious.
- `llmClient` overrides process DNS servers globally. This is an unexpected infrastructure side effect, can violate deployment/network policy, and is not a robust reliability strategy.
- Raw upstream OpenRouter error response text is placed in an Error and logged, potentially leaking provider details or sensitive echoed content.
- No per-user AI quotas, cost budget, concurrency control, cache strategy, abuse controls beyond the general API limiter, or token/input size limits specific to AI exist. The API accepts large request bodies globally (10 MB).
- Chat history is client-supplied and trusted as context. There is no server-side conversation identity, authorization, integrity, retention control, or history length/token accounting beyond slicing a few entries.
- Patient summary sends more context than is necessarily needed, including billing-derived context in a clinical summary.
- Bed allocation and appointment optimization are advisory only and disconnected from a confirmation/reservation transaction. Users can mistake a recommendation for an allocation or booking.
- Admin “high risk” logic samples the first eight patients without a meaningful risk query/order and infers risk only from chronic-condition count. It can omit truly high-risk patients and creates false confidence.
- Revenue trends use bill/payment aggregates without a financial ledger, and appointment trends mix `createdAt` with operational appointment dates.
- No evaluation suite exists for triage recall, unsafe advice rate, JSON conformance, hallucinations, subgroup fairness, multilingual behavior, prompt injection, or fallback equivalence.
- No human review/acknowledgement, correction capture, incident reporting, model-version audit, or post-deployment monitoring workflow exists.
- No clear policy distinguishes wellness guidance, clinical decision support, and administrative automation. These require different risk controls and user messaging.

## Medium-priority findings (P2)

- Frontend route protection and menus are not a security boundary and occasionally disagree with backend roles. AI Agents and Doctors pages are open to all authenticated frontend users.
- Notifications are hard-coded demo content with realistic statements (“lab report ready”, “appointments today”, stock alerts). This is misleading and should be clearly labeled demo data or replaced by event-backed notifications.
- `DoctorSchedule` falls back to a mock schedule when real data is absent, which can misrepresent clinician availability.
- API errors are normalized inconsistently; many UI call sites use `err.message` although useful server messages live under `err.response.data.message`.
- Backend has two email modules/services with potentially different semantics.
- Legacy Mongoose model files remain even though the runtime uses Prisma. Comments, Mongo-compatible response virtuals, legacy endpoints, migration scripts, and `isMongoId` validation obscure the source of truth.
- README claims “100% REST API compatibility” and fully migrated behavior despite known endpoint mismatches and legacy assumptions.
- Build output was historically committed even though `frontend/dist/` is ignored, creating noisy diffs and stale deploy artifacts.
- Production API fallback URL and CORS deployment URLs are hard-coded, increasing environment drift.
- The health endpoint reports success without awaiting or querying database health; startup logs a DB connection failure but continues serving.
- Unhandled rejection handling only closes the server when it is already not listening, which is inverted and does not perform reliable graceful shutdown.
- No pagination limits are capped; invalid `page`/`limit` values can produce bad queries or excessive responses.
- Several dashboard/report calculations load full tables and aggregate in JavaScript rather than using database aggregation, which will not scale.
- Billing page produces an oversized bundle chunk (~532 kB minified); PDF/chart dependencies should be lazy-loaded.
- Accessibility and keyboard/focus behavior need dedicated testing for custom modals, tables, chatbot widgets, and mobile navigation.
- No lint, unit test, integration test, end-to-end test, type-check, coverage, security scan, or CI command is defined in package scripts.

## Recommended delivery plan

### Phase 0 — Establish safety gates and a reproducible baseline (1–2 days)

1. Freeze new features until P0 authorization paths are addressed.
2. Add CI commands for lint, backend unit/integration tests, frontend component tests, production build, Prisma validation, migration deploy check, and dependency/security scanning.
3. Create seeded test personas for every primary and sub-role and a disposable test database.
4. Build an endpoint inventory from Express routes and a frontend-call inventory; fail CI when documented client calls lack server routes.
5. Add environment validation and fail-fast startup for secrets/configuration.

Exit criteria: one command can create a test DB, migrate, seed, test, and build; missing required production secrets stop startup.

### Phase 1 — Close confidentiality and authorization gaps (2–4 days)

1. Define a written authorization matrix covering resource, action, role, ownership, care-team relationship, and returned fields.
2. Implement reusable policy helpers for Patient, Appointment, Prescription, Billing, LabReport, Ward, upload, report, and AI contexts.
3. Apply policies to all detail and nested endpoints, not only lists. Add adversarial IDOR tests for every role/resource pair.
4. Restrict AI tools by role and require own-patient enforcement for patient summaries.
5. Move protected uploads behind authorized download endpoints or signed short-lived object-storage URLs.
6. Remove the JWT fallback secret; add session revocation/rotation design and implement real logout.
7. Redact sensitive request logging and define audit events for every read/export/mutation of clinical data.

Exit criteria: automated tests prove that swapping any patient/bill/appointment/prescription ID cannot cross tenant/ownership/care-team boundaries.

### Phase 2 — Make core workflows transactional and stateful (4–7 days)

1. Wrap user/profile creation, prescription dispensing, appointment completion/billing, bed assignment/discharge, and payment processing in Prisma transactions.
2. Add explicit state machines for appointments, prescriptions, admissions/beds, bills, insurance claims, and lab reports.
3. Add database constraints/conditional updates for appointment collisions, active bed assignment, stock non-negativity, payment balance, and idempotency keys.
4. Replace patient hard deletion with archive/deactivation and retention-aware access.
5. Consolidate legacy/new ward endpoints and remove obsolete Mongo validators/response assumptions after compatibility tests.
6. Resolve all frontend/backend contract mismatches: auth logout, appointment delete, patient history/prescriptions/bills, and unrouted report features.

Exit criteria: fault-injection tests show operations either commit completely or roll back; concurrent booking/payment/dispense tests preserve invariants.

### Phase 3 — Complete clinical and operational workflows (1–2 weeks)

1. Introduce a first-class Encounter/Admission model linking appointment, clinician, ward/bed, diagnosis, orders, results, prescription, discharge, and billing.
2. Build a lab order-to-result lifecycle with specimen status, reviewer/sign-off, amendments, critical-result acknowledgement, and patient-release rules.
3. Build inventory batches and an immutable stock movement ledger; add recall, expiry, FEFO, reconciliation, and adjustment reasons.
4. Add prescription safety rules and clinician approval/refill controls.
5. Integrate a real payment provider using payment intents and signed idempotent webhooks; add refunds, voids, credit notes, and reconciliation.
6. Replace static notifications with event-backed notification records and delivery status.
7. Align Prisma enums, seed data, README roles, backend authorization, dashboards, and navigation around one canonical role model.

Exit criteria: each patient journey can be followed as a single auditable episode from registration through follow-up and reconciliation.

### Phase 4 — Harden AI as decision support (1–2 weeks, then ongoing)

1. Classify every AI feature by risk. Keep operational summaries separate from clinical decision support.
2. Add strict request validation and structured-output schema validation. Reject or safely regenerate malformed output.
3. Add input size/token limits, prompt-injection defenses, de-identification/minimum-necessary context, explicit consent/policy controls, and provider retention configuration.
4. Never use fabricated availability after API failure. Surface degraded mode clearly; recommendations must be confirmed against current transactional data before booking/allocation.
5. Add deterministic emergency escalation independent of the LLM, with clinically reviewed coverage and locale-specific wording; support multilingual input explicitly.
6. Display provenance (rules vs model), model/version, timestamp, data freshness, limitations, and “requires human review” on clinical output.
7. Add an evaluation harness with curated and adversarial cases: emergencies, negation, ambiguity, pediatric/obstetric cases, self-harm, multilingual inputs, injection, malformed reports, subgroup analysis, JSON conformance, and fallback parity.
8. Add cost, latency, failure, fallback, safety-event, and clinician-override telemetry without logging raw protected health information.
9. Require clinician acknowledgement before AI summaries or recommendations influence the permanent record; capture corrections for monitored improvement.

Exit criteria: each release passes safety/effectiveness thresholds, all AI data access is authorized/audited, and no AI recommendation directly mutates care state without validated human confirmation.

### Phase 5 — Reliability, performance, and release readiness (3–5 days)

1. Make readiness depend on a successful database query; implement correct SIGTERM/SIGINT shutdown and Prisma disconnect.
2. Add bounded pagination, database aggregations/index review, query performance budgets, and load tests.
3. Lazy-load billing PDF/chart dependencies and establish frontend bundle budgets.
4. Remove tracked build artifacts and obsolete Mongoose code only after migration verification and repository-owner approval.
5. Add backup/restore drills, migration rollback/forward-fix procedure, monitoring, alerting, SLOs, and incident response.
6. Perform accessibility, privacy, threat-model, and deployment reviews before any real patient use.

Exit criteria: staging passes role-based E2E tests, load and recovery drills, security review, AI evaluation gates, and operational readiness review.

## Suggested test matrix

- Authentication: register atomicity, login, inactive user, reset enumeration, expired token, revoked session, missing-secret startup.
- Authorization: every role against every list/detail/mutation/export/AI endpoint; own versus other patient; clinician assigned versus unassigned.
- Appointments: conflicting concurrent bookings, invalid transitions, timezone boundaries, cancellation ownership, reschedule conflict, billing idempotency.
- Prescriptions: concurrent dispense, insufficient stock, refill eligibility, cancelled/expired prescription, duplicate request idempotency.
- Ward: concurrent bed assignment, double discharge, counter reconciliation, inactive ward, admission linkage.
- Billing: concurrent partial payments, overpayment, duplicate webhook, partial insurance approval, rejection, refund/void, exact rounding.
- Clinical data: history child-record ownership, lab amendment/sign-off, upload authorization, audit trail completeness.
- AI: role denial, own-patient summary, prompt injection, malformed JSON, provider timeout, clear fallback labeling, emergency recall, multilingual and negation cases, no direct mutation.
- Deployment: fresh migration/seed, database unavailable readiness, graceful shutdown, CORS per environment, upload persistence.

## Definition of production-ready for this project

Production-ready should mean more than a successful build: no known P0/P1 authorization defect; transactional invariants under concurrency; immutable auditability for clinical and financial actions; a tested recovery path; accurate role/data minimization; real or explicitly simulated external workflows; and clinically governed AI that is advisory, traceable, evaluated, and never silently degraded.
