import re
from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path('/Users/kanishkgandecha/Projects/Medilink')
SOURCE = ROOT / 'docs/medilink-research-paper-supervisor-draft.md'
OUTPUT = ROOT / 'docs/MediLink_Research_Paper_Supervisor_Draft.docx'

NAVY = '16324F'
BLUE = '2E74B5'
LIGHT = 'EAF1F8'
PALE = 'F4F6F9'
GRAY = '5B6573'
WHITE = 'FFFFFF'
RED = '9B1C1C'

def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tc_pr.append(shd)
    shd.set(qn('w:fill'), fill)

def shade_paragraph(paragraph, fill, border='D9E2EC'):
    p_pr = paragraph._p.get_or_add_pPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    p_pr.append(shd)
    p_bdr = OxmlElement('w:pBdr')
    for edge in ('top', 'left', 'bottom', 'right'):
        elem = OxmlElement(f'w:{edge}')
        elem.set(qn('w:val'), 'single')
        elem.set(qn('w:sz'), '4')
        elem.set(qn('w:space'), '6')
        elem.set(qn('w:color'), border)
        p_bdr.append(elem)
    p_pr.append(p_bdr)

def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in('w:tcMar')
    if tc_mar is None:
        tc_mar = OxmlElement('w:tcMar')
        tc_pr.append(tc_mar)
    for tag, value in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tc_mar.find(qn(f'w:{tag}'))
        if node is None:
            node = OxmlElement(f'w:{tag}')
            tc_mar.append(node)
        node.set(qn('w:w'), str(value))
        node.set(qn('w:type'), 'dxa')

def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement('w:tblHeader')
    tbl_header.set(qn('w:val'), 'true')
    tr_pr.append(tbl_header)

def set_table_geometry(table, widths_dxa, indent=120):
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn('w:tblW'))
    if tbl_w is None:
        tbl_w = OxmlElement('w:tblW')
        tbl_pr.append(tbl_w)
    tbl_w.set(qn('w:w'), str(sum(widths_dxa)))
    tbl_w.set(qn('w:type'), 'dxa')
    tbl_ind = tbl_pr.find(qn('w:tblInd'))
    if tbl_ind is None:
        tbl_ind = OxmlElement('w:tblInd')
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn('w:w'), str(indent))
    tbl_ind.set(qn('w:type'), 'dxa')
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement('w:gridCol')
        col.set(qn('w:w'), str(width))
        grid.append(col)
    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            width = widths_dxa[idx]
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn('w:tcW'))
            if tc_w is None:
                tc_w = OxmlElement('w:tcW')
                tc_pr.append(tc_w)
            tc_w.set(qn('w:w'), str(width))
            tc_w.set(qn('w:type'), 'dxa')
            cell.width = Inches(width / 1440)
            set_cell_margins(cell)

def set_font(run, size=10.5, bold=False, italic=False, color=None, name='Aptos'):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn('w:ascii'), name)
    run._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'), name)
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)

def add_runs(paragraph, text, size=10.5, color=None, italic_all=False):
    pattern = re.compile(r'(\*\*.*?\*\*|\*[^*]+?\*|`[^`]+?`|\[[^\]]+\]\([^\)]+\))')
    pos = 0
    for match in pattern.finditer(text):
        if match.start() > pos:
            set_font(paragraph.add_run(text[pos:match.start()]), size=size, color=color, italic=italic_all)
        token = match.group(0)
        if token.startswith('**'):
            set_font(paragraph.add_run(token[2:-2]), size=size, bold=True, color=color)
        elif token.startswith('*'):
            set_font(paragraph.add_run(token[1:-1]), size=size, italic=True, color=color)
        elif token.startswith('`'):
            set_font(paragraph.add_run(token[1:-1]), size=size-0.5, color=NAVY, name='Consolas')
        else:
            m = re.match(r'\[([^\]]+)\]\(([^\)]+)\)', token)
            run = paragraph.add_run(m.group(1))
            set_font(run, size=size, color=BLUE)
            run.underline = True
        pos = match.end()
    if pos < len(text):
        set_font(paragraph.add_run(text[pos:]), size=size, color=color, italic=italic_all)

def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run('Page ')
    set_font(run, size=9, color=GRAY)
    fld = OxmlElement('w:fldSimple')
    fld.set(qn('w:instr'), 'PAGE')
    paragraph._p.append(fld)

def create_decimal_numbering(doc):
    numbering = doc.part.numbering_part.element
    abstract_ids = [int(x.get(qn('w:abstractNumId'))) for x in numbering.findall(qn('w:abstractNum'))]
    num_ids = [int(x.get(qn('w:numId'))) for x in numbering.findall(qn('w:num'))]
    abstract_id = max(abstract_ids, default=0) + 1
    num_id = max(num_ids, default=0) + 1

    abstract = OxmlElement('w:abstractNum')
    abstract.set(qn('w:abstractNumId'), str(abstract_id))
    multi = OxmlElement('w:multiLevelType')
    multi.set(qn('w:val'), 'singleLevel')
    abstract.append(multi)
    lvl = OxmlElement('w:lvl')
    lvl.set(qn('w:ilvl'), '0')
    start = OxmlElement('w:start')
    start.set(qn('w:val'), '1')
    num_fmt = OxmlElement('w:numFmt')
    num_fmt.set(qn('w:val'), 'decimal')
    lvl_text = OxmlElement('w:lvlText')
    lvl_text.set(qn('w:val'), '%1.')
    suff = OxmlElement('w:suff')
    suff.set(qn('w:val'), 'tab')
    p_pr = OxmlElement('w:pPr')
    tabs = OxmlElement('w:tabs')
    tab = OxmlElement('w:tab')
    tab.set(qn('w:val'), 'num')
    tab.set(qn('w:pos'), '720')
    tabs.append(tab)
    ind = OxmlElement('w:ind')
    ind.set(qn('w:left'), '720')
    ind.set(qn('w:hanging'), '360')
    p_pr.extend([tabs, ind])
    lvl.extend([start, num_fmt, lvl_text, suff, p_pr])
    abstract.append(lvl)
    numbering.append(abstract)

    num = OxmlElement('w:num')
    num.set(qn('w:numId'), str(num_id))
    ref = OxmlElement('w:abstractNumId')
    ref.set(qn('w:val'), str(abstract_id))
    num.append(ref)
    numbering.append(num)
    return num_id

def apply_numbering(paragraph, num_id):
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = OxmlElement('w:numPr')
    ilvl = OxmlElement('w:ilvl')
    ilvl.set(qn('w:val'), '0')
    num = OxmlElement('w:numId')
    num.set(qn('w:val'), str(num_id))
    num_pr.extend([ilvl, num])
    p_pr.append(num_pr)

def style_document(doc):
    sec = doc.sections[0]
    sec.page_width = Inches(8.5)
    sec.page_height = Inches(11)
    sec.top_margin = Inches(0.82)
    sec.bottom_margin = Inches(0.75)
    sec.left_margin = Inches(0.88)
    sec.right_margin = Inches(0.88)
    sec.header_distance = Inches(0.35)
    sec.footer_distance = Inches(0.35)

    normal = doc.styles['Normal']
    normal.font.name = 'Aptos'
    normal._element.rPr.rFonts.set(qn('w:ascii'), 'Aptos')
    normal._element.rPr.rFonts.set(qn('w:hAnsi'), 'Aptos')
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    specs = {
        'Heading 1': (16, NAVY, 16, 7),
        'Heading 2': (13, BLUE, 12, 5),
        'Heading 3': (11.5, NAVY, 9, 4),
    }
    for name, (size, color, before, after) in specs.items():
        style = doc.styles[name]
        style.font.name = 'Aptos Display'
        style._element.rPr.rFonts.set(qn('w:ascii'), 'Aptos Display')
        style._element.rPr.rFonts.set(qn('w:hAnsi'), 'Aptos Display')
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for section in doc.sections:
        hp = section.header.paragraphs[0]
        hp.text = 'MEDILINK  |  SUPERVISOR DISCUSSION DRAFT'
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        hp.paragraph_format.space_after = Pt(2)
        for run in hp.runs:
            set_font(run, size=8.5, bold=True, color=GRAY)
        add_page_number(section.footer.paragraphs[0])

def add_cover(doc):
    for _ in range(4):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run('RESEARCH PAPER DRAFT')
    set_font(r, size=11, bold=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(14)
    p.paragraph_format.keep_with_next = True
    r = p.add_run('MediLink')
    set_font(r, size=32, bold=True, color=NAVY, name='Aptos Display')

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(28)
    r = p.add_run('A Safety-Oriented AI-Assisted Hospital Information System\nfor Explainable Clinical Decision Support')
    set_font(r, size=17, color=BLUE, name='Aptos Display')

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(24)
    r = p.add_run('Supervisor discussion draft  |  24 August 2026')
    set_font(r, size=11, bold=True, color=GRAY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(6)
    add_runs(p, 'Kanishk Gandecha  •  Kanan Goenka  •  Keshav Rathi', size=11, color=NAVY)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_runs(p, '[Department and institution to be confirmed]', size=10.5, color=GRAY, italic_all=True)

    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.75)
    p.paragraph_format.right_indent = Inches(0.75)
    p.paragraph_format.space_before = Pt(7)
    p.paragraph_format.space_after = Pt(7)
    shade_paragraph(p, PALE)
    add_runs(p, 'Pre-experimental manuscript: numerical results, dataset details, clinical evaluation, and institutional declarations remain explicitly marked for completion.', size=10, color=RED)
    doc.add_page_break()

def add_table(doc, rows):
    cols = len(rows[0])
    table = doc.add_table(rows=len(rows), cols=cols)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    if cols == 2:
        widths = [3300, 6060]
    elif cols == 3:
        widths = [2600, 3300, 3460]
    elif cols == 9:
        widths = [1500] + [982] * 8
    else:
        widths = [9360 // cols] * cols
        widths[-1] += 9360 - sum(widths)
    set_table_geometry(table, widths)
    set_repeat_table_header(table.rows[0])
    for ri, row in enumerate(table.rows):
        for ci, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if ri == 0:
                set_cell_shading(cell, NAVY)
            elif ri % 2 == 0:
                set_cell_shading(cell, PALE)
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.line_spacing = 1.0
            text = rows[ri][ci]
            p.clear()
            add_runs(p, text, size=7.5 if cols == 9 else 9, color=WHITE if ri == 0 else None)
            for run in p.runs:
                if ri == 0:
                    run.bold = True
    doc.add_paragraph().paragraph_format.space_after = Pt(1)

def parse_markdown(doc, lines):
    i = 0
    in_abstract = False
    active_decimal_num = None
    while i < len(lines):
        line = lines[i].rstrip()
        if not line:
            i += 1
            continue
        if not re.match(r'^\d+\. ', line):
            active_decimal_num = None
        if line.startswith('# '):
            i += 1
            continue
        if line.startswith('**Authors:**') or line.startswith('**Affiliation:**') or line.startswith('**Corresponding author:**'):
            i += 1
            continue
        if line.startswith('> '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(5)
            p.paragraph_format.space_after = Pt(5)
            shade_paragraph(p, LIGHT)
            add_runs(p, line[2:], size=9.5, color=NAVY)
            i += 1
            continue
        if line.startswith('## '):
            title = line[3:]
            if title.startswith('Appendix A:'):
                doc.add_page_break()
            p = doc.add_paragraph(style='Heading 1')
            add_runs(p, title, size=16, color=NAVY)
            in_abstract = title == 'Abstract'
            i += 1
            continue
        if line.startswith('### '):
            p = doc.add_paragraph(style='Heading 2')
            add_runs(p, line[4:], size=13, color=BLUE)
            i += 1
            continue
        if line.startswith('|') and i + 1 < len(lines) and re.match(r'^\|?\s*:?-+', lines[i + 1].strip()):
            rows = []
            rows.append([c.strip() for c in line.strip('|').split('|')])
            i += 2
            while i < len(lines) and lines[i].strip().startswith('|'):
                rows.append([c.strip() for c in lines[i].strip().strip('|').split('|')])
                i += 1
            add_table(doc, rows)
            continue
        if re.match(r'^\d+\. ', line):
            if active_decimal_num is None:
                active_decimal_num = create_decimal_numbering(doc)
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            p.paragraph_format.space_after = Pt(4)
            apply_numbering(p, active_decimal_num)
            add_runs(p, re.sub(r'^\d+\. ', '', line), size=10.5)
            i += 1
            continue
        if line.startswith('- '):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            p.paragraph_format.space_after = Pt(4)
            add_runs(p, line[2:], size=10.5)
            i += 1
            continue
        p = doc.add_paragraph()
        p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.first_line_indent = Inches(0.22) if not in_abstract else Inches(0)
        p.paragraph_format.widow_control = True
        add_runs(p, line, size=10.5)
        i += 1

def main():
    lines = SOURCE.read_text(encoding='utf-8').splitlines()
    doc = Document()
    style_document(doc)
    add_cover(doc)
    parse_markdown(doc, lines)
    props = doc.core_properties
    props.title = 'MediLink: A Safety-Oriented AI-Assisted Hospital Information System for Explainable Clinical Decision Support'
    props.subject = 'Supervisor discussion draft'
    props.author = 'Kanishk Gandecha; Kanan Goenka; Keshav Rathi'
    props.keywords = 'MediLink, clinical decision support, explainable AI, hospital information system'
    doc.save(OUTPUT)
    print(OUTPUT)

if __name__ == '__main__':
    main()
