# MediLink: A Safety-Oriented AI-Assisted Hospital Information System for Explainable Clinical Decision Support

**Supervisor discussion draft — 24 August 2026**

**Authors:** Kanishk Gandecha; Kanan Goenka; Keshav Rathi [ORDER AND SPELLING TO BE CONFIRMED]  
**Affiliation:** [DEPARTMENT, INSTITUTION, CITY, COUNTRY TO BE PROVIDED]  
**Corresponding author:** [TO BE PROVIDED]

> Status note: This is an honest pre-experimental manuscript draft. It distinguishes the implemented MediLink software from the proposed predictive-machine-learning study. Numerical results, dataset characteristics, clinical evaluation, and institutional approvals are deliberately marked `[TO BE PROVIDED]`. The manuscript must not be submitted until those items are completed and verified.

## Abstract

Hospital information systems consolidate administrative and clinical activities, but longitudinal patient information can remain difficult to review and computational decision support can introduce risks related to opacity, uncertainty, privacy, and automation bias. This paper presents MediLink, a web-based hospital information system and a proposed safety-oriented framework for integrating explainable clinical risk support into routine information workflows. The implemented prototype uses a React/Vite frontend, a Node.js/Express application programming interface, and PostgreSQL through Prisma. It supports role-oriented workflows for patient management, appointments, prescriptions, pharmacy inventory, wards, billing, reports, and operational dashboards. Its current artificial-intelligence layer includes large-language-model-assisted and deterministic functions for symptom guidance, report explanation, patient summaries, appointment guidance, bed-allocation guidance, pharmacy alerts, and administrative insights. These functions are assistive prototypes and have not been clinically validated. The experimental extension proposed in this study will evaluate [PREDICTION TASK TO BE PROVIDED] using [DATASET TO BE PROVIDED], comparing [MODELS TO BE PROVIDED] against a baseline. Evaluation will report discrimination, calibration, classification performance, missing-data robustness, subgroup performance where supported, and inference latency. Model explanations, abstention for insufficient or out-of-scope inputs, versioned audit records, and clinician accept/override/dismiss controls are proposed as safety mechanisms. Results are `[TO BE PROVIDED]`. MediLink is not intended to diagnose, prescribe, or replace professional judgment. Its intended contribution is a reproducible integration pattern joining hospital workflow software with traceable, uncertainty-aware, human-reviewed decision support. Benchmark performance would not establish clinical effectiveness; external and prospective clinical validation would remain necessary.

**Keywords:** clinical decision support; hospital information system; explainable artificial intelligence; human-in-the-loop; calibration; patient safety; auditability

## 1 Introduction

Electronic information systems can improve the organization and availability of hospital data, yet the presence of digitized records does not guarantee that clinically relevant information is easy to identify. A clinician may need to combine demographics, allergies, prior encounters, medications, laboratory results, and recent changes under time pressure. Artificial intelligence (AI) may help prioritize or summarize such information, but introducing AI into this setting also creates new failure modes. Predictions may be poorly calibrated, generative outputs may be unsupported, performance may vary across populations, and users may place excessive trust in an apparently confident interface.

International guidance consequently emphasizes transparency, accountability, human autonomy, safety, inclusiveness, and continuous assessment for health AI [1]. Reporting guidance such as TRIPOD+AI requires a complete account of prediction-model development and evaluation, including discrimination, calibration, and clinical utility [2]. DECIDE-AI further emphasizes human factors and early-stage evaluation of AI decision-support systems in their intended workflows [3]. These principles imply that adding a chatbot to a hospital application is not sufficient to constitute reliable clinical decision support.

MediLink is a final-year engineering project exploring how an assistive AI layer can be integrated with a hospital information system without granting the AI autonomous clinical authority. The current implementation provides an operational software prototype and several generative or rule-based AI demonstrations. It does not yet contain a validated predictive model. This paper therefore has two purposes: (1) to describe the implemented MediLink architecture accurately, including its limitations; and (2) to specify a reproducible experiment for a narrower explainable-risk module with uncertainty handling and clinician oversight.

The intended research contribution is not the set of conventional create-read-update-delete modules. It is the design and evaluation of a traceable integration pattern in which structured data, predictive output, explanation, abstention, and human review are kept distinct. The following research questions are proposed:

- **RQ1:** How do selected interpretable and ensemble machine-learning models compare in discrimination and calibration for [SELECTED CLINICAL RISK TASK]?
- **RQ2:** How does abstention for missing or out-of-scope inputs affect predictive performance and coverage?
- **RQ3:** How can explanations and clinician accept/override/dismiss actions be integrated while preserving the original model output and an auditable decision history?
- **RQ4:** What latency and reliability overhead results from integrating the proposed prediction service with MediLink?

## 2 Related Work

### 2.1 Clinical prediction and reporting quality

Clinical prediction studies require more than reporting accuracy. Discrimination measures whether a model separates outcome groups, whereas calibration measures agreement between predicted probabilities and observed outcomes. A model may discriminate reasonably while producing probabilities that are systematically too high or too low. For a system displaying individual risk, both properties matter. TRIPOD+AI provides a 27-item framework for transparent reporting of regression- and machine-learning-based prediction studies [2]. PROBAST+AI separates model-development quality from risk of bias in performance estimates and explicitly considers fairness and applicability [4]. The proposed MediLink experiment will use these frameworks during study design rather than only after results are generated.

### 2.2 Explainability and human oversight

SHAP provides additive feature attributions for explaining model behavior at global and individual levels [5]. Such explanations can help inspect whether a model relies on clinically plausible or potentially spurious inputs. They do not establish causal relationships and cannot independently establish safety. MediLink will therefore label explanations as descriptions of model behavior and place them beside, rather than above, the underlying patient information.

Human oversight must be operational rather than rhetorical. DECIDE-AI identifies the AI algorithm, software platform, hardware, users, intended use, and human–computer interaction as parts of the evaluated system [3]. The proposed interface records whether an authorized clinician accepts, overrides, or dismisses an assessment. The original prediction is retained, and an override does not retrain the model automatically.

### 2.3 Trustworthy and deployable health AI

The FUTURE-AI consensus framework organizes trustworthy health AI around fairness, universality, traceability, usability, robustness, and explainability [6]. WHO guidance similarly places ethics and human rights at the center of design and use [1]. These frameworks motivate MediLink's proposed auditability, minimum-necessary data flow, explicit limitation messages, and separation of clinical authority from model output. FDA clinical decision-support guidance also demonstrates why intended user, intended use, and the ability of a healthcare professional to review the basis of a recommendation are important distinctions [7]. This paper does not assert a regulatory classification or legal compliance.

### 2.4 Research gap

Published health-AI work frequently concentrates either on isolated predictive performance or on general governance principles. Hospital-management projects, meanwhile, often emphasize functional modules without evaluating the safety and integration behavior of an embedded model. A defensible gap for this study is therefore narrower: there is value in experimentally documenting how a modest predictive model can be integrated into an auditable hospital-information workflow with calibrated output, explanation, abstention, failure isolation, and explicit human review. This is a systems-and-evaluation contribution, not a claim of a novel clinical algorithm.

## 3 MediLink System

### 3.1 Implemented architecture

The audited implementation consists of three principal layers:

1. A React 18 frontend built with Vite, React Router, Axios, and role-oriented navigation.
2. A Node.js/Express REST API using JSON Web Token bearer authentication, password hashing, security headers, cross-origin configuration, validation middleware, and request rate limiting.
3. A PostgreSQL relational database accessed through Prisma. The schema includes users, doctors, patients, appointments, prescriptions, medicines, wards and beds, bills and payments, medical history, laboratory reports, imaging data, and admissions.

This description corrects earlier planning material that referred to MongoDB. Legacy Mongoose files and compatibility identifiers remain in the repository, but the active server controllers use Prisma/PostgreSQL.

**Figure 1 — Proposed overall system architecture.** Role-specific patient, clinician, and administrative interfaces communicate with the authenticated Express API. Core hospital workflows use PostgreSQL independently of the optional AI layer. The proposed prediction service receives a minimum validated feature set, returns versioned structured output, and passes through explanation, abstention, and audit components before clinician review.

### 3.2 Implemented hospital workflows

The prototype includes patient and clinician profiles, appointment scheduling, prescriptions and dispensing, medicine inventory, ward and bed operations, billing and insurance-record simulation, administrative reports, and role-specific dashboards. These features establish the application context but are not individually claimed as research contributions.

The present clinical record supports medical history, medications, laboratory reports, imaging information, admissions, appointments, prescriptions, and bills. A complete real-world longitudinal record would additionally require a first-class encounter model, observations/vital signs, signed clinical notes, diagnostic and procedure records, result verification, amendments, and immutable authorship history.

### 3.3 Current AI features

The current AI layer uses an OpenRouter-compatible large language model when configured and deterministic rule-based fallbacks otherwise. It includes symptom guidance, report explanation, health-risk guidance, bed-allocation guidance, appointment optimization, patient summaries, and a conversational assistant. Administrative insights and pharmacy alerts are deterministic analytics rather than learned AI models.

These capabilities have not been evaluated as predictive clinical models. Their output must not be described as diagnosis, treatment, or validated risk estimation. Automatic fallback improves availability but can obscure provider failure; the interface should visibly disclose provenance and degraded mode. Bed and appointment recommendations must be confirmed against transactional data and must not directly reserve resources based only on model output.

### 3.4 Current security limitations

The codebase has authentication and coarse role checks, but the audit identified object-level authorization gaps affecting patient, appointment, billing, prescription, and AI-summary access. A default JWT fallback secret, public static uploads, non-transactional multi-record operations, and incomplete audit logging also prevent a production-security claim. These are implementation limitations, not completed safeguards. The research prototype should close the relevant authorization paths before processing even synthetic experiment records through the integrated interface.

## 4 Proposed Predictive Decision-Support Module

### 4.1 Intended use

The module will estimate `[OUTCOME TO BE PROVIDED]` for `[TARGET POPULATION TO BE PROVIDED]` using `[INPUT FEATURES TO BE PROVIDED]`. The intended user is an authorized clinician reviewing an existing patient record. It will not establish a diagnosis, prescribe medication, automatically modify the clinical record, or suppress standard clinical workflow.

The output language will follow the form: “Elevated predicted risk based on the available variables; clinician review required.” If mandatory information is missing or the case falls outside the validated scope, the module will return “Insufficient information for reliable prediction.”

### 4.2 Proposed inference workflow

Validated patient inputs → feature-schema validation → missingness and applicability check → model inference → probability calibration → risk presentation → local explanation → clinician accept/override/dismiss → immutable audit event.

The stored audit event should include the model name and version, training-dataset version, feature-schema version, prediction timestamp, input-record version or hash, raw predicted probability, displayed category, explanation payload, abstention reason, clinician action, clinician identifier, timestamp, and optional override reason.

### 4.3 Failure isolation

The hospital-management functions must remain usable when the AI provider or prediction service is unavailable. AI calls should have bounded timeouts and structured error responses. No fabricated prediction, available appointment slot, or bed allocation should be substituted for missing live data. Failed or degraded output must be recognizable to the user and observable in non-sensitive operational telemetry.

## 5 Dataset and Data Preparation

The experimental dataset is `[TO BE PROVIDED]`. Before experimentation, the following facts must be documented:

| Property | Required value |
|---|---|
| Dataset name and authoritative source | [TO BE PROVIDED] |
| Licence and permitted use | [TO BE PROVIDED] |
| Public, synthetic, institutional, or combined | [TO BE PROVIDED] |
| Population and collection setting | [TO BE PROVIDED] |
| Number of records and patients | [TO BE PROVIDED] |
| Predictor variables | [TO BE PROVIDED] |
| Outcome and prediction horizon | [TO BE PROVIDED] |
| Inclusion and exclusion criteria | [TO BE PROVIDED] |
| Missingness by variable | [TO BE PROVIDED] |
| Outcome prevalence/class distribution | [TO BE PROVIDED] |
| Demographic variables available for subgroup analysis | [TO BE PROVIDED] |
| Ethics/consent requirements | [TO BE PROVIDED] |

If synthetic records are used for software demonstrations, they will be explicitly separated from the dataset used to train and evaluate the model. Synthetic demonstration data will not be described as real patients. If any institution-provided data are considered, ethics approval, lawful access, consent or waiver, de-identification, data-security controls, and institutional permission must be documented before use.

Data preparation will be defined before accessing final test labels. Duplicate records and patient overlap between partitions will be checked. Imputation, encoding, scaling, feature selection, outlier rules, class-imbalance treatment, and calibration will be fitted using training data only. The split strategy must account for repeated observations and time where applicable; random row splitting is inappropriate if rows from the same patient can appear in multiple partitions.

## 6 Experimental Methodology

### 6.1 Candidate models

The final set depends on dataset size and feature types. A reasonable initial comparison is:

- A prevalence or simple rule baseline.
- Logistic regression as an interpretable statistical baseline.
- Decision tree as a nonlinear interpretable comparator.
- Random forest or gradient boosting as a stronger nonlinear model.

A neural network is not automatically justified for a modest tabular dataset. Hyperparameters will be selected inside cross-validation or a validation partition; the held-out test set will be used once for final evaluation.

### 6.2 Evaluation measures

The study will report accuracy, precision, recall/sensitivity, specificity, F1-score, ROC-AUC, PR-AUC, and confusion matrices where appropriate. Calibration will be assessed using a calibration plot, calibration intercept/slope where feasible, and Brier score. Confidence intervals will be calculated using `[BOOTSTRAP OR OTHER METHOD TO BE PROVIDED]`. Subgroup results will be reported only for variables present in the dataset and only where sample size supports meaningful interpretation.

| Model | Accuracy | Precision | Recall | Specificity | F1 | ROC-AUC | PR-AUC | Brier score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Baseline | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] |
| Logistic regression | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] |
| Decision tree | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] |
| Ensemble model | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] | [TBD] |

### 6.3 Explainability experiment

Global feature importance and representative local explanations will be generated for the selected model. Explanation stability will be examined under small plausible input changes. Error analysis will inspect false negatives and false positives, model reliance on missingness proxies, and subgroup differences. Feature attribution will be described as model behavior rather than biological causation.

### 6.4 Abstention and missing-data experiment

Evaluation cases will be subjected to controlled missingness patterns. The system will abstain when mandatory variables are absent or when a predefined applicability rule is violated. Results will report coverage—the proportion receiving predictions—alongside performance on retained cases. Thresholds must be selected using development data and justified rather than tuned on the test set.

### 6.5 Integration and reliability experiment

The integrated API will be tested for median and tail latency, throughput, timeout behavior, malformed input, service unavailability, duplicate requests, and audit-record consistency. The exact hardware, software versions, request workload, warm-up, sample count, and measurement procedure are `[TO BE PROVIDED]`.

## 7 Results

No numerical model results are currently available. This section will be completed only from preserved experiment outputs.

Planned figures are:

- **Figure 2:** Receiver-operating-characteristic curves for all evaluated models.
- **Figure 3:** Precision–recall curves, emphasizing behavior under the observed outcome prevalence.
- **Figure 4:** Calibration curves before and after any calibration procedure.
- **Figure 5:** Confusion matrix for the selected operating threshold.
- **Figure 6:** Global SHAP summary and one de-identified local explanation.
- **Figure 7:** Coverage–performance trade-off for abstention.
- **Figure 8:** End-to-end inference latency distribution.

Required result statements:

- Best-discriminating model: `[TO BE PROVIDED]`.
- Best-calibrated model: `[TO BE PROVIDED]`.
- Selected model and selection rationale: `[TO BE PROVIDED]`.
- Important failure cases: `[TO BE PROVIDED]`.
- Subgroup findings: `[TO BE PROVIDED OR NOT EVALUABLE]`.
- Abstention result: `[TO BE PROVIDED]`.
- API latency and failure result: `[TO BE PROVIDED]`.

## 8 Discussion

The discussion will interpret the actual results rather than assume that the most complex model performs best. It will separately address discrimination, calibration, operating-threshold consequences, false-negative and false-positive errors, subgroup behavior, explanation limitations, abstention, and computational cost. If a simpler model performs comparably, its transparency and deployment simplicity may justify selection.

Even strong internal performance on a public benchmark would not demonstrate clinical effectiveness. Differences in population, measurement, prevalence, workflow, and data quality may substantially affect performance. External, temporal, and prospective evaluation would be required before clinical use. Any usability study must state participant qualifications; student or developer feedback cannot be represented as clinician validation.

## 9 Safety, Ethics, Privacy, and Human Oversight

MediLink is framed as clinical decision support. The clinician remains responsible for reviewing the patient information and making the final decision. AI output will not automatically create diagnoses, prescriptions, allergies, or treatment plans. An override preserves the original prediction and records the reviewer action.

Key hazards include false negatives, false positives, missing or incorrect inputs, distribution shift, subgroup bias, unsupported generative statements, prompt injection, unauthorized record access, and automation bias. Proposed mitigations include scope checks, abstention, calibrated probabilities, explanation, explicit provenance, least-privilege authorization, minimum-necessary data transfer, model versioning, audit logs, and failure isolation. These controls reduce risk but do not establish clinical safety.

Current LLM features send user-entered or record-derived context to an external provider when configured. A real deployment would require a documented data-processing basis, de-identification where possible, provider retention controls, consent and institutional policies, encryption, access auditing, and jurisdiction-specific legal review. The project does not presently claim compliance with any healthcare law or certification.

## 10 Limitations

This draft describes a prototype whose predictive experiment has not yet been executed. The dataset and clinical task remain to be selected. The current generative AI features have not undergone clinical evaluation, hallucination measurement, multilingual safety testing, or clinician usability testing. The underlying hospital application has known authorization, auditability, workflow, and concurrency limitations identified by the codebase audit. No real hospital deployment, external validation, prospective study, or patient-outcome evaluation has occurred. If a public or synthetic dataset is used, its results may not generalize to a local hospital population. Explanations describe model behavior and do not establish causation. The proposed architecture is therefore a research prototype and foundation for future validation, not a deployable medical device or autonomous clinical system.

## 11 Conclusion and Future Work

MediLink demonstrates a substantial hospital-information-system prototype and provides a practical environment in which to study integration of explainable, uncertainty-aware decision support. Its strongest defensible research direction is a focused evaluation of one predictive task combined with calibration, abstention, explanation, versioned auditability, and clinician-controlled review. The study must report actual data and experiments transparently and must not equate benchmark performance with clinical effectiveness. Future work includes external and temporal validation, structured clinician evaluation, longitudinal encounter modeling, stronger security controls, standards-based interoperability, model monitoring, and controlled clinical investigation under appropriate institutional governance.

## Declarations

**Funding:** [TO BE PROVIDED / “The authors received no specific funding for this work.” TO BE CONFIRMED]  
**Competing interests:** [TO BE PROVIDED]  
**Ethics approval:** [TO BE PROVIDED; state “not applicable” only after dataset and study design are confirmed]  
**Consent to participate:** [TO BE PROVIDED]  
**Consent for publication:** [TO BE PROVIDED]  
**Data availability:** [TO BE PROVIDED]  
**Code availability:** [TO BE PROVIDED]  
**Author contributions:** [TO BE PROVIDED]

## References

1. World Health Organization. *Ethics and governance of artificial intelligence for health*. Geneva: WHO; 2021. ISBN 978-92-4-002920-0. https://www.who.int/publications/i/item/9789240029200
2. Collins GS, Moons KGM, Dhiman P, et al. TRIPOD+AI statement: updated guidance for reporting clinical prediction models that use regression or machine learning methods. *BMJ*. 2024;385:e078378. https://doi.org/10.1136/bmj-2023-078378
3. Vasey B, Nagendran M, Campbell B, et al. Reporting guideline for the early-stage clinical evaluation of decision support systems driven by artificial intelligence: DECIDE-AI. *Nature Medicine*. 2022;28:924–933. https://doi.org/10.1038/s41591-022-01772-9
4. Moons KGM, Damen JAA, Kaul T, et al. PROBAST+AI: an updated quality, risk of bias, and applicability assessment tool for prediction models using regression or artificial intelligence methods. *BMJ*. 2025;388:e082505. https://doi.org/10.1136/bmj-2024-082505
5. Lundberg SM, Lee S-I. A unified approach to interpreting model predictions. In: *Advances in Neural Information Processing Systems 30*. 2017. https://papers.nips.cc/paper_files/paper/2017/hash/8a20a8621978632d76c43dfd28b67767-Abstract.html
6. Lekadir K, Frangi AF, Porras AR, et al. FUTURE-AI: international consensus guideline for trustworthy and deployable artificial intelligence in healthcare. *BMJ*. 2025;388:e081554. https://doi.org/10.1136/bmj-2024-081554
7. U.S. Food and Drug Administration. *Clinical Decision Support Software: Guidance for Industry and Food and Drug Administration Staff*. September 2022. https://www.fda.gov/media/162880/download
8. Liu X, Cruz Rivera S, Moher D, Calvert MJ, Denniston AK, SPIRIT-AI and CONSORT-AI Working Group. Reporting guidelines for clinical trial reports for interventions involving artificial intelligence: the CONSORT-AI extension. *Nature Medicine*. 2020;26:1364–1374. https://doi.org/10.1038/s41591-020-1034-x

## Appendix A: Implementation-status statement for supervisor review

| Area | Status on 24 August 2026 | Permitted manuscript wording |
|---|---|---|
| React/Express/PostgreSQL hospital system | Implemented prototype | “Implemented” |
| Role-based interfaces and coarse API authorization | Implemented but security gaps remain | “Prototype controls; not production-secure” |
| LLM and deterministic AI agents | Implemented prototype | “Assistive, unvalidated prototype” |
| Predictive ML model | Not implemented/evaluated | “Proposed experimental module” |
| Dataset | Not selected | `[TO BE PROVIDED]` |
| SHAP/explainability | Proposed | “Planned methodology” |
| Calibrated uncertainty/abstention | Proposed | “Planned methodology” |
| Clinician override and AI audit history | Proposed | “Planned design” |
| RAG with evidence citations | Not implemented | “Future work” |
| Clinical validation | Not performed | Must state explicitly |
| Hospital deployment | Not performed | Must state explicitly |

## Appendix B: Decisions needed from the supervisor

1. Approve or revise the focused research direction: one explainable and calibrated prediction task integrated with MediLink.
2. Select the clinical task and approve the dataset source.
3. Confirm whether the expected submission is a system paper, prediction-model paper, or both.
4. Confirm whether any qualified clinicians can review terminology/interface design; do not imply validation if none are available.
5. Confirm the target submission date, manuscript length, author order, and institutional declarations.
6. Approve use of TRIPOD+AI and PROBAST+AI to design and report the experiment.
7. Decide which current AI demonstrations should remain in the paper as context and which should be relegated to future work.

## Appendix C: Work required before the Results section can be completed

1. Select and document the dataset and prediction target.
2. Produce a data dictionary and missingness/class-distribution report.
3. Pre-register or freeze the split, preprocessing, models, metrics, and thresholds.
4. Train baseline and candidate models reproducibly.
5. Evaluate discrimination, calibration, error cases, subgroups, and uncertainty/abstention.
6. Add explanation output and preserve representative, de-identified examples.
7. Integrate the chosen model with versioned API and audit records.
8. Run latency, failure, security, and authorization tests.
9. Preserve scripts, seeds, package versions, logs, and raw result tables.
10. Replace every `[TO BE PROVIDED]` only from verified evidence.
