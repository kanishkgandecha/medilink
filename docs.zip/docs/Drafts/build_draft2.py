from pathlib import Path
import shutil
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from docx.shared import Pt

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "MediLink Research Draft 1.docx"
OUTPUT = ROOT / "MediLink Research Draft 2.docx"

shutil.copy2(SOURCE, OUTPUT)
doc = Document(OUTPUT)

title = doc.paragraphs[0]
title.text = (
    "MediLink: A Proposed Safety-Oriented Framework for Explainable and "
    "Human-in-the-Loop Machine Learning in Hospital Information Systems"
)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title.paragraph_format.space_after = Pt(10)
for run in title.runs:
    run.bold = True
    run.font.name = "Times New Roman"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Times New Roman")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Times New Roman")
    run.font.size = Pt(16)

anchor = title._p

def insert_centered(after_element, text, *, size=11, bold=False, italic=False, after=2):
    p = OxmlElement("w:p")
    after_element.addnext(p)
    paragraph = Paragraph(p, title._parent)
    paragraph.text = text
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_after = Pt(after)
    for run in paragraph.runs:
        run.bold = bold
        run.italic = italic
        run.font.name = "Times New Roman"
        run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Times New Roman")
        run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Times New Roman")
        run.font.size = Pt(size)
    return p

anchor = insert_centered(anchor, "Kanishk Gandecha, Kanan Goenka, and Keshav Rathi", bold=True, after=2)
anchor = insert_centered(
    anchor,
    "K J Somaiya School of Engineering, Somaiya Vidyavihar University, "
    "Mumbai, Maharashtra, India",
    italic=True,
    after=3,
)
anchor = insert_centered(anchor, "Proposed Research Paper Draft - Version 2", italic=True, size=10, after=10)

# LibreOffice collapses adjacent paragraphs when Word's automatic paragraph
# spacing flags are combined with direct spacing. Preserve the source's exact
# spacing values while removing those renderer-dependent automatic flags.
for paragraph in doc.paragraphs:
    spacing = paragraph._p.xpath("./w:pPr/w:spacing")
    if spacing:
        spacing[0].attrib.pop(qn("w:beforeAutospacing"), None)
        spacing[0].attrib.pop(qn("w:afterAutospacing"), None)
    if paragraph.text == "examine model behavior when patient information is missing.":
        paragraph.text = "Examine model behavior when patient information is missing."
        for run in paragraph.runs:
            run.font.name = "Times New Roman"
            run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Times New Roman")
            run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Times New Roman")
            run.font.size = Pt(12)
    text = paragraph.text.strip()
    if re.match(r"^\d+\.\s", text):
        paragraph.paragraph_format.space_before = Pt(12)
        paragraph.paragraph_format.space_after = Pt(6)
        paragraph.paragraph_format.keep_with_next = True
    if text.startswith("Phase "):
        paragraph.paragraph_format.space_before = Pt(10)
        paragraph.paragraph_format.space_after = Pt(5)
        paragraph.paragraph_format.keep_with_next = True
    if text == "The hospital-management functions should remain usable when the prediction service is unavailable.":
        paragraph.paragraph_format.space_before = Pt(10)
        paragraph.paragraph_format.space_after = Pt(8)
    if text == "The proposed study addresses these concerns through a safety-oriented integration framework.":
        paragraph.paragraph_format.page_break_before = True

doc.core_properties.title = title.text
doc.core_properties.subject = "Proposed combined systems-and-machine-learning research paper"
doc.core_properties.author = "Kanishk Gandecha; Kanan Goenka; Keshav Rathi"
doc.core_properties.keywords = "MediLink, hospital information system, machine learning, explainable AI"
doc.save(OUTPUT)
print(OUTPUT)
